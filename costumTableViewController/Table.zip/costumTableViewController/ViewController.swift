//
//  ViewController.swift
//  costumTableViewController
//
//  Created by Toon van Dort on 08/04/15.
//  Copyright (c) 2015 Toon van Dort. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {
    
    let transportItems = ["Mijn Vakken","Mijn Werkplekken","Projecten | Follow","Projecten | Coach"]
    
    let deadlineIcons = [""]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return transportItems.count
    }
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCellWithIdentifier("transportCell") as UITableViewCell
        
        cell.textLabel!.text = transportItems[indexPath.row]
        
        var imageName = UIImage(named: transportItems[indexPath.row])
        cell.imageView!.image = imageName
        
        return cell
    }
}

